# OCTANET_AUGUST
octanet internship task
